"""
DataJobs India — EXE Launcher
Wraps the Streamlit app so PyInstaller can bundle it into a single .exe
"""
import sys
import os
import threading
import webbrowser
import time


def resource_path(relative_path: str) -> str:
    """Return absolute path — works both in dev and when frozen by PyInstaller."""
    if getattr(sys, "frozen", False):
        base = sys._MEIPASS          # PyInstaller temp folder
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, relative_path)


def open_browser():
    """Wait a few seconds for Streamlit to start, then open the browser."""
    time.sleep(4)
    webbrowser.open("http://localhost:8501")


if __name__ == "__main__":
    # Open browser in background thread
    threading.Thread(target=open_browser, daemon=True).start()

    # Launch Streamlit via its CLI
    from streamlit.web import cli as stcli

    script = resource_path("job.py")
    sys.argv = [
        "streamlit", "run", script,
        "--server.port=8501",
        "--server.headless=true",
        "--browser.gatherUsageStats=false",
        "--theme.base=light",
    ]
    sys.exit(stcli.main())
