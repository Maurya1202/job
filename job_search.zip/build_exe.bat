@echo off
title DataJobs India — EXE Builder
echo =========================================
echo   DataJobs India EXE Builder
echo =========================================
echo.

:: Check Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python is not installed or not in PATH.
    echo Download it from https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [1/3] Installing dependencies...
pip install -r requirements.txt -q
if %errorlevel% neq 0 (
    echo ERROR: Failed to install dependencies.
    pause
    exit /b 1
)

echo [2/3] Building EXE with PyInstaller...
echo        (This may take 2-5 minutes — please wait)
echo.

:: Locate streamlit package path for bundling its static assets
for /f "delims=" %%i in ('python -c "import streamlit, os; print(os.path.dirname(streamlit.__file__))"') do set STREAMLIT_PATH=%%i

pyinstaller ^
    --onefile ^
    --windowed ^
    --name "DataJobsIndia" ^
    --add-data "job.py;." ^
    --add-data "%STREAMLIT_PATH%\static;streamlit/static" ^
    --add-data "%STREAMLIT_PATH%\runtime;streamlit/runtime" ^
    --collect-all streamlit ^
    --collect-all altair ^
    --collect-all pydeck ^
    --hidden-import streamlit ^
    --hidden-import streamlit.web.cli ^
    --hidden-import streamlit.runtime.scriptrunner ^
    --hidden-import duckduckgo_search ^
    --hidden-import ddgs ^
    --hidden-import altair ^
    --hidden-import pydeck ^
    launcher.py

if %errorlevel% neq 0 (
    echo.
    echo ERROR: Build failed. See above for details.
    pause
    exit /b 1
)

echo.
echo [3/3] Done!
echo.
echo Your EXE is ready:  dist\DataJobsIndia.exe
echo.
echo Share the file in the "dist" folder with anyone.
echo They just double-click it — no Python needed!
echo.
pause
