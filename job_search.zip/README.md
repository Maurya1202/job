# DataJobs India — How to Build the EXE

## What you need (one-time setup)
- Windows 10 or 11
- Python 3.10–3.12 installed from https://www.python.org/downloads/
  ✅ Tick "Add Python to PATH" during installation!

---

## Build the EXE (takes ~3-5 minutes)

1. Put all these files in the **same folder**:
   - `job.py`
   - `launcher.py`
   - `requirements.txt`
   - `build_exe.bat`

2. Double-click **`build_exe.bat`**

3. Wait for it to finish. When done, you'll see:
   ```
   dist\DataJobsIndia.exe
   ```

4. Share `DataJobsIndia.exe` with anyone — that's it!

---

## How the EXE works
- User double-clicks `DataJobsIndia.exe`
- A browser window opens automatically at `http://localhost:8501`
- The DataJobs India app is ready to use — no Python, no install needed

---

## Troubleshooting
| Problem | Fix |
|---------|-----|
| `python not found` | Install Python and tick "Add to PATH" |
| Antivirus blocks the EXE | Add an exception; PyInstaller EXEs are flagged as false positives |
| App doesn't open in browser | Manually visit `http://localhost:8501` |
| Black window flashes and closes | Run from Command Prompt to see the error message |
